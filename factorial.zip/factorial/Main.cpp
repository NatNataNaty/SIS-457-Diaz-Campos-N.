#include<iostream>
using namespace std;

class factorial;
{
public:
	int n;
	Calcular(int x) {
		int acum = 1;
		for (int i = 0; i < n; i++) {
			acum += 1;
		}
		return acum
	}
	factorial() {

	}
}
int main{

 return 0

};

